
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'cerchiariluiza',
  applicationName: 'blog',
  appUid: 'jHLVMbxPrvGg0J6W8K',
  orgUid: '3f9a3d72-2fda-46ab-b394-b783b5c3c972',
  deploymentUid: '5ea0315e-b72a-4b00-8854-d130763ace96',
  serviceName: 'blog',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'blog-dev-createService', timeout: 6 };

try {
  const userHandler = require('./articles/create.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}