commit 1
serverless create -t aws-nodejs -n blog
serverless deploy
serverless invoke -f createArticle